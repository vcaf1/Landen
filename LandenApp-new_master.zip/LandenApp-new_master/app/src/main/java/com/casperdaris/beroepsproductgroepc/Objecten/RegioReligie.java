package com.casperdaris.beroepsproductgroepc.Objecten;

public class RegioReligie {

    private String religieNaam;

    public RegioReligie(String religieNaam) {
        this.religieNaam = religieNaam;
    }

    public String getReligieNaam() {
        return religieNaam;
    }

    public void setReligieNaam(String religieNaam) {
        this.religieNaam = religieNaam;
    }

}
