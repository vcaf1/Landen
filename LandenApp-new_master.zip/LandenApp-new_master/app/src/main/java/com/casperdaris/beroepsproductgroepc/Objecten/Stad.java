package com.casperdaris.beroepsproductgroepc.Objecten;

public class Stad {

    private String stadNaam;

    public Stad(String stadNaam) {
        this.stadNaam = stadNaam;
    }

    public String getStadNaam() {
        return stadNaam;
    }

    public void setStadNaam(String stadNaam) {
        this.stadNaam = stadNaam;
    }

}
