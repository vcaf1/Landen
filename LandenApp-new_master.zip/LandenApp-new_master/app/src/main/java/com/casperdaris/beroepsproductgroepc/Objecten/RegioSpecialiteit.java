package com.casperdaris.beroepsproductgroepc.Objecten;

public class RegioSpecialiteit {

    private String specialiteitNaam;

    public RegioSpecialiteit(String specialiteitNaam) {
        this.specialiteitNaam = specialiteitNaam;
    }

    public String getSpecialiteitNaam() {
        return specialiteitNaam;
    }

    public void setSpecialiteitNaam(String specialiteitNaam) {
        this.specialiteitNaam = specialiteitNaam;
    }
}
