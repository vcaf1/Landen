package com.casperdaris.beroepsproductgroepc.Objecten;

public class Religie {

    private String religie;

    public Religie(String religie) {
        this.religie = religie;
    }

    public String getReligie() {
        return religie;
    }

    public void setReligie(String religie) {
        this.religie = religie;
    }
}