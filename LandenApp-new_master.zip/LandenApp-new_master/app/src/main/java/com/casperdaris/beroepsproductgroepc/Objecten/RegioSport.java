package com.casperdaris.beroepsproductgroepc.Objecten;

public class RegioSport {

    private String sportNaam;

    public RegioSport(String sportNaam) {
        this.sportNaam = sportNaam;
    }

    public String getSportNaam() {
        return sportNaam;
    }

    public void setSportNaam(String sportNaam) {
        this.sportNaam = sportNaam;
    }

}
