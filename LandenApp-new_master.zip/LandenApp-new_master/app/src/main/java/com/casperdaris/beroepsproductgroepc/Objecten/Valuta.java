package com.casperdaris.beroepsproductgroepc.Objecten;

public class Valuta {

    private String valutaNaam;

    public Valuta(String valutaNaam) {
        this.valutaNaam = valutaNaam;
    }

    public void setValutaNaam(String valutaNaam) {
        this.valutaNaam = valutaNaam;
    }

    public String getValutaNaam() {
        return valutaNaam;
    }

}
