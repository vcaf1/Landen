package com.casperdaris.beroepsproductgroepc.Objecten;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.HashMap;

public class Taal {

    private String taal;

    public Taal(String taal) {
        this.taal = taal;
    }

    public String getTaal() {
        return taal;
    }

    public void setTaal(String taal) {
        this.taal = taal;
    }

}
